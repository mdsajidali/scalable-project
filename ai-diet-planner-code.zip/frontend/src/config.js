// Set this to be configurable for production
export const API_BASE_URL = process.env.REACT_APP_API_URL || '';
export const APP_NAME = 'AI Diet Planner';